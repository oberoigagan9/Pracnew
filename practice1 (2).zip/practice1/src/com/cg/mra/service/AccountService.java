package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.InvalidMobileNoException;
import com.cg.mra.exceptions.MobileNoNotFoundException;

public interface AccountService {
	Account getAccountDetails(String mobileNo)
	throws MobileNoNotFoundException,InvalidMobileNoException;
	double rechargeAccount(String mobileNo,double rechargeAmount);

}
