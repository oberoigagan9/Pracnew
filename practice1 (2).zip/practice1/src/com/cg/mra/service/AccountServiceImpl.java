package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exceptions.InvalidMobileNoException;
import com.cg.mra.exceptions.MobileNoNotFoundException;

public class AccountServiceImpl implements AccountService {
AccountDao dao=new AccountDaoImpl();
	@Override
	public Account getAccountDetails(String mobileNo) throws MobileNoNotFoundException, InvalidMobileNoException {
		Account detail=dao.getAccountDetails(mobileNo);
		if(mobileNo.length()<10) 
			throw new InvalidMobileNoException("Sorry pal not a valid no");
		if(detail==null)
			throw new MobileNoNotFoundException("Mobile no ain't there");
		
		
		 return detail;
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		return dao.rechargeAccount(mobileNo, rechargeAmount);
	}

}
